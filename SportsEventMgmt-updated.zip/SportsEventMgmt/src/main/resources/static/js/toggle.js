$(function() {
	var bool = true;
	$('#hidden').hide();
	$('#login-form-link').click(function(e) {

		$("#login-form").delay(100).fadeIn(100);
		$("#register-form").fadeOut(100);
		$('#register-form-link').removeClass('active');
		$(this).addClass('active');
		e.preventDefault();
	});
	$('#register-form-link').click(function(e) {
		$("#register-form").delay(100).fadeIn(100);
		$("#login-form").fadeOut(100);
		$('#login-form-link').removeClass('active');
		$(this).addClass('active');
		e.preventDefault();
	});

	$('#remember').click(function() {
		if (document.getElementById("remember").checked) {
			// alert("hello");
			document.getElementById('hidden').disabled = true;
		}
	})

	$("#rpassword").keyup(function() {
		$("#confirm").show();
	});

	$("#confirm-password").keyup(
			function() {

				if ($("#r-password").val() == $("#confirm-password").val()) {
					$("#confirm-msg-f").hide();
					$("#confirm-msg-t").show();
					$("#confirm-msg-t").html(
							"password and confirm password matched!");
					bool = true;
				} else {
					$("#confirm-msg-t").hide();
					$("#confirm-msg-f").show();
					$("#confirm-msg-f").html(
							"password and confirm password doesn't match!");
					bool = false;
				}
			});

	$("#register-form").submit(function() {
		if (bool == false)
			alert("To submit the form both password field should match!");
		return bool;
	});

})