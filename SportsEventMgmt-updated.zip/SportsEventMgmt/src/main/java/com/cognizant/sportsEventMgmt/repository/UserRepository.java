package com.cognizant.sportsEventMgmt.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.cognizant.sportsEventMgmt.model.User;

//Repository for Users

public interface UserRepository extends JpaRepository<User, Integer> {

	// Repository method for authenticating users for login

	@Query("select u from User u where emailId=?1 and password=?2")
	User authenticateUser(String emailId, String password);
}