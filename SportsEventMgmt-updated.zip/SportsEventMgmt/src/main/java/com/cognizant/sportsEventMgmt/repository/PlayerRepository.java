package com.cognizant.sportsEventMgmt.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cognizant.sportsEventMgmt.model.Player;

//Repository for Players

@Repository
public interface PlayerRepository extends JpaRepository<Player, Integer> {

	// Repository method for getting players by coach id

	List<Player> getPlayerBycId(int cId);

	// Repository method for updating players

	@Transactional
	@Modifying
	@Query("update Player p set playerName=?1, emailId=?2 ,contactNumber=?3 ,age=?4,gender=?5 where pId=?6")
	void updatePlayer(String playerName, String emailId, String contactNumber, String age, String gender, int pId);

	// Repository method for updating the events id of particular player

	@Transactional
	@Modifying
	@Query("update Player p set eId=?1 where pId=?2")
	void updatePlayerId(int eId, int pId);
}