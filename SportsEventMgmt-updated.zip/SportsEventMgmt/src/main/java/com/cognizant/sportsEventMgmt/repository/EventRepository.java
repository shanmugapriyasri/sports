package com.cognizant.sportsEventMgmt.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cognizant.sportsEventMgmt.model.Event;

//Repository for Events

@Repository
public interface EventRepository extends JpaRepository<Event, Integer> {

	// Repository method for getting the events by event name

	List<Event> getByEventName(String eventName);

	// Repository method for updating events

	@Transactional
	@Modifying
	@Query("update Event set  eventDate=?1 ,eventTime=?2 ,noOfSlots=?3 where eId=?4")
	void updatEvent(String eventDate, String eventTime, String noOfSlots, int eId);
	@Query("select e from Event e ORDER BY eId")
	List<Event> findTopByOrderById();

}
