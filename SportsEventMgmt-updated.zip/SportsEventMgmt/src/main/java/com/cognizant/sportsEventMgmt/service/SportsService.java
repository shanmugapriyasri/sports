package com.cognizant.sportsEventMgmt.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.cognizant.sportsEventMgmt.model.Event;
import com.cognizant.sportsEventMgmt.model.Participation;
import com.cognizant.sportsEventMgmt.model.Player;
import com.cognizant.sportsEventMgmt.model.Sports;
import com.cognizant.sportsEventMgmt.model.User;

//This is a service layer

@Service
public interface SportsService {
	// Service method for registering new users
	public void addUser(User user);

	// Service method for authenticating users
	public User authenticateUser(String emailId, String password);

	// Service method for adding new sports
	public void addSports(Sports sports);

	// Service method for getting a sports by id
	public Optional<Sports> findSportsById(int id);

	// Service method for updating an existing sports
	public void updateSports(String noOfPlayers, String timeOfMatch, int sId);

	// Service method for deleting an existing sports
	public void deleteSports(int sId);

	// Service method to view all the existing sports
	public List<Sports> viewSports();

	// Service method to auto-generate sports name for adding event
	public List<String> getSportsList();

	// Service method for adding new event
	public void addEvent(Event event);

	// Service method for getting a event by eId
	public Optional<Event> findEventById(int eId);

	// Service method for updating an existing event
	public void updateEvent(String eventDate, String eventTime, String noOfSlots, int eId);

	// Service method for deleting an existing event
	public void deleteEvent(int eId);

	// Service method to view all the existing events
	public List<Event> viewEvent();

	// Service method to auto-generate event name for adding players
	public List<Participation> getEventList(int cId, String status);

	// Service method for adding new players
	public void addPlayer(Player player);

	// Service method for getting the event by its name
	public List<Event> getEventListByEventName(String eventName);

	// Service method for updating player's event id
	public void updatePlayerId(int eId, int pId);

	// Service method for getting a player by pId
	public Optional<Player> findPlayerById(int pId);

	// Service method for updating an existing player
	public void updatePlayer(String playerName, String emailId, String contactNumber, String age, String gender,
			int pId);

	// Service method for deleting an existing player
	public void deletePlayer(int pId);

	// Service method to view all the existing players
	public List<Player> viewPlayerById(int cId);

	// Service method to add new participations for the events
	public void addParticipation(Participation participation);

	// Service method to view existing participations based on participation and
	// event id
	public List<Participation> viewExistingParticipation(int cId, int eId);

	// Service method to view all the participations request
	public List<Participation> viewParticipation(String status);

	// Service method to update an existing participation request
	public void updateParticipation(String status, int partId, int eId, int cId);

	// Service method to view participations based on coach id
	public List<Participation> viewParticipationById(int cId);
}
