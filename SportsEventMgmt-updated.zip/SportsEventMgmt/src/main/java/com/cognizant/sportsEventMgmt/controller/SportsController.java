package com.cognizant.sportsEventMgmt.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cognizant.sportsEventMgmt.model.Event;
import com.cognizant.sportsEventMgmt.model.Participation;
import com.cognizant.sportsEventMgmt.model.Player;
import com.cognizant.sportsEventMgmt.model.Sports;
import com.cognizant.sportsEventMgmt.model.User;
import com.cognizant.sportsEventMgmt.service.SportsService;

//This is a controller class

@Controller
public class SportsController {
	@Autowired
	private SportsService sportsService;

	private HttpSession session;

	// Mapping for starting index page
	@RequestMapping(value = "/indexPage")
	public String indexPage(@ModelAttribute("user") User user, Model m) {
		user = new User();
		m.addAttribute("display1", "block");
		m.addAttribute("display2", "none");
		return "index";
	}

	// Mapping for organizer page
	@RequestMapping(value = "/organizerPage")
	public String organizerPage(@ModelAttribute("user") User user) {
		user = new User();
		return "organizer";
	}

	// Mapping for coach page
	@RequestMapping(value = "/coachPage")
	public String coachPage(@ModelAttribute("user") User user) {
		user = new User();
		return "coach";
	}

	// Mapping for registering a new user
	@RequestMapping(value = "/registerUser", method = RequestMethod.POST)
	public String registerPage(@Valid @ModelAttribute("user") User user, BindingResult bindingResult, Model m) {
		if (bindingResult.hasErrors()) {
			m.addAttribute("display1", "none");
			m.addAttribute("display2", "block");
			return "index";
		}
		try {
			sportsService.addUser(user);
		} catch (Exception e) {
			m.addAttribute("display1", "block");
			m.addAttribute("display2", "none");
			m.addAttribute("errMsg", "Email Id is already registered. Please Sign in.");
			return "index";
		}
		m.addAttribute("display1", "block");
		m.addAttribute("display2", "none");
		return "redirect:/indexPage";
	}

	// Mapping for the login page where the user is authenticated
	@RequestMapping(value = "/authenticateUser", method = RequestMethod.POST)
	public String authenticateUser(@RequestParam String emailId, @RequestParam String password,
			HttpServletRequest request, Model model) {
		model.addAttribute(new User());
		User user = sportsService.authenticateUser(emailId, password);
		if (user != null) {
			session = request.getSession();
			if (user.getUserType().equalsIgnoreCase("Organizer")) {
				session.setAttribute("oid", user.getId());
				return "organizer";
			} else {
				session.setAttribute("cid", user.getId());
				String coachName = "" + user.getFirstName() + " " + user.getLastName();
				session.setAttribute("coachName", coachName);
				return "coach";
			}
		} else {
			model.addAttribute("display1", "block");
			model.addAttribute("display2", "none");
			model.addAttribute("status", "Invalid username/password");
			return "index";
		}
	}

	// Mapping for sign out page
	@RequestMapping(value = "/requestSignOut")
	public String requestSignOut() {
		return "signOut";
	}

	// Mapping for addSports page
	@RequestMapping(value = "/addSports")
	public String addSports(@ModelAttribute("sports") Sports sports) {
		sports = new Sports();
		return "addSports";
	}

	// Mapping for adding a new sports
	@RequestMapping(value = "/addSportsData", method = RequestMethod.POST)
	public String addSportsData(@Valid @ModelAttribute("sports") Sports sports, BindingResult bindingResult) {

		if (bindingResult.hasErrors()) {
			return "addSports";
		}
		sportsService.addSports(sports);
		return "redirect:/viewSports";
	}

	// Mapping for the updateSports page
	@RequestMapping(value = "/updateSports")
	public String updateSports(@ModelAttribute("sports") Sports sports, Model model, @RequestParam("sId") int sId) {
		sports = new Sports();
		Optional<Sports> s = sportsService.findSportsById(sId);

		model.addAttribute("sports", s.get());
		return "updateSports";
	}

	// Mapping for updating an existing sports
	@RequestMapping(value = "/updateSportsData", method = RequestMethod.POST)
	public String updateSportsData(@Valid @ModelAttribute("sports") Sports sports, BindingResult bindingResult,
			@RequestParam("noOfPlayers") String noOfPlayers, @RequestParam("timeOfMatch") String timeOfMatch,
			@RequestParam("sId") int sId) {

		if (bindingResult.hasErrors()) {
			return "updateSports";
		}
		sportsService.updateSports(noOfPlayers, timeOfMatch, sId);
		return "redirect:/viewSports";
	}

	// Mapping for deleting an existing sports
	@RequestMapping(value = "/deleteSports")
	public String deleteSports(@ModelAttribute("sports") Sports sports, BindingResult bindingResult,
			@RequestParam("sId") int sId) {
		sportsService.deleteSports(sId);
		return "redirect:/viewSports";
	}

	// Mapping to view all the existing sports
	@RequestMapping(value = "/viewSports")
	public String viewSports(Model m) {
		List<Sports> sportsList = sportsService.viewSports();
		m.addAttribute("sportsList", sportsList);
		return "viewSports";
	}

	// Mapping for addEvent page
	@RequestMapping(value = "/addEvent")
	public String addEvent(@ModelAttribute("event") Event event) {
		event = new Event();
		return "addEvent";
	}

	// Auto-generated sports list for adding events
	@ModelAttribute("sportsList")
	public List<String> sportsList(Model model) {
		List<String> sportsList = new ArrayList<String>();
		sportsList = sportsService.getSportsList();
		model.addAttribute("sportsList", sportsList);
		return sportsList;
	}

	// Mapping for adding a new Event
	@RequestMapping(value = "/addEventData", method = RequestMethod.POST)
	public String addEventData(@Valid @ModelAttribute("event") Event event, BindingResult bindingResult) {
		if (bindingResult.hasErrors()) {
			return "addEvent";
		}
		sportsService.addEvent(event);
		return "redirect:/viewEvent";
	}

	// Mapping for the updateEvent page
	@RequestMapping(value = "/updateEvent")
	public String updateEvent(@RequestParam int eId, @ModelAttribute("event") Event event, Model model) {
		event = new Event();
		Optional<Event> e = sportsService.findEventById(eId);
		model.addAttribute("event", e.get());

		return "updateEvent";
	}

	// Mapping for updating an existing event
	@RequestMapping(value = "/updateEventData", method = RequestMethod.POST)
	public String updateEventData(@Valid @ModelAttribute("event") Event event, BindingResult bindingResult,
			HttpServletRequest request, HttpServletResponse response) {
		if (bindingResult.hasErrors()) {
			return "updateEvent";
		}
		String eventDate = event.getEventDate();
		String eventTime = event.getEventTime();
		String noOfSlots = event.getNoOfSlots();
		int eId = event.geteId();
		sportsService.updateEvent(eventDate, eventTime, noOfSlots, eId);
		return "redirect:/viewEvent";
	}

	// Mapping for deleting an existing Event
	@RequestMapping(value = "/deleteEvent")
	public String deleteEvent(@ModelAttribute("event") Event event, BindingResult bindingResult,
			@RequestParam("eId") int eId) {
		sportsService.deleteEvent(eId);
		return "redirect:/viewEvent";
	}

	// Mapping to view all the existing events
	@RequestMapping(value = "/viewEvent")
	public String viewSEvent(Model m) {
		List<Event> eventList = sportsService.viewEvent();
		m.addAttribute("eventList", eventList);
		return "viewEvent";
	}

	// Mapping for addPlayer page
	@RequestMapping(value = "/addPlayer")
	public String addPlayer(@ModelAttribute("player") Player player, @RequestParam int cId, Model model) {
		player = new Player();
		String status = "accepted";
		List<Participation> list = sportsService.getEventList(cId, status);
		List<String> eventList = new ArrayList<String>();
		for (Participation participation : list) {
			eventList.add(participation.getEventName());
		}
		model.addAttribute("eventList", eventList);
		return "addPlayer";
	}

	// Mapping for adding a new Player
	@RequestMapping(value = "/addPlayerData", method = RequestMethod.POST)
	public String addPlayerData(@Valid @ModelAttribute("player") Player player, BindingResult bindingResult) {
		if (bindingResult.hasErrors()) {
			return "addPlayer";
		}
		sportsService.addPlayer(player);
		String eventName = player.getEventName();
		List<Event> list = sportsService.getEventListByEventName(eventName);
		int eId = list.get(0).geteId();
		int pId = player.getpId();
		sportsService.updatePlayerId(eId, pId);
		return "redirect:/viewPlayer?cId=" + player.getcId();
	}

	// Mapping for the updatePlayer page
	@RequestMapping(value = "/updatePlayer")
	public String updatePlayer(@RequestParam int pId, @ModelAttribute("player") Player player, Model model) {
		player = new Player();
		Optional<Player> p = sportsService.findPlayerById(pId);
		model.addAttribute(p.get());
		return "updatePlayer";
	}

	// Mapping for updating an existing player
	@RequestMapping(value = "/updatePlayerData", method = RequestMethod.POST)
	public String updatePlayerData(@Valid @ModelAttribute("player") Player player, BindingResult bindingResult,
			HttpServletRequest request, HttpServletResponse response) {
		if (bindingResult.hasErrors()) {
			return "updatePlayer";
		}
		String emailId = player.getEmailId();
		String contactNumber = player.getContactNumber();
		String age = player.getAge();
		String gender = player.getGender();
		String playerName = player.getPlayerName();
		int pId = player.getpId();
		sportsService.updatePlayer(playerName, emailId, contactNumber, age, gender, pId);
		return "redirect:/viewPlayer?cId=" + player.getcId();
	}

	// Mapping for deleting an existing player
	@RequestMapping(value = "/deletePlayer")
	public String deletePlayer(@ModelAttribute("player") Player player, BindingResult bindingResult,
			@RequestParam("pId") int pId, @RequestParam("cId") int cId) {
		sportsService.deletePlayer(pId);
		return "redirect:/viewPlayer?cId=" + cId;
	}

	// Mapping to view all the existing players
	@RequestMapping(value = "/viewPlayer")
	public String viewPlayer(@RequestParam int cId, Model m) {
		List<Player> playerList = sportsService.viewPlayerById(cId);
		m.addAttribute("playerList", playerList);
		return "viewPlayer";
	}

	// Mapping for the eventParticipation page
	@RequestMapping(value = "/eventParticipation")
	public String eventParticipation(@ModelAttribute("participation") Participation participation, Model m,
			@RequestParam("cId") int cId) {
		List<Event> allEventList = sportsService.viewEvent();
		List<Event> eventList = new ArrayList<>();
		for (Event event : allEventList) {
			List<Participation> temp = sportsService.viewExistingParticipation(cId, event.geteId());
			System.out.println();
			if (temp.size() == 0) {
				eventList.add(event);
			}
		}
		m.addAttribute("eventList", eventList);
		return "eventParticipation";
	}

	// Mapping for adding a new participation
	@RequestMapping(value = "/addParticipation", method = RequestMethod.POST)
	public String addParticipation(@Valid @ModelAttribute("participation") Participation participation,
			BindingResult bindingResult, Model m, @RequestParam("cId") int cId) {
		if (bindingResult.hasErrors()) {
			return "redirect:/eventParticipation?cId=" + cId;
		}
		sportsService.addParticipation(participation);
		return "redirect:/eventParticipation?cId=" + cId;
	}

	// Mapping to view all the participations
	@RequestMapping(value = "/viewParticipation")
	public String viewParticipation(@ModelAttribute("participation") Participation participation, Model m) {
		participation = new Participation();
		String status = "requested";
		List<Participation> partList = sportsService.viewParticipation(status);
		m.addAttribute("partList", partList);
		return "viewParticipation";
	}

	// Mapping for updating the status of participation
	@RequestMapping(value = "/updateParticipation", method = RequestMethod.POST)
	public String updatePlayerData(@ModelAttribute("participation") Participation participation,
			HttpServletRequest request, HttpServletResponse response) {
		int partId = participation.getPartId();
		int eId = participation.geteId();
		int cId = participation.getcId();
		String status = participation.getStatus();
		sportsService.updateParticipation(status, partId, eId, cId);
		return "redirect:/viewParticipation";
	}

	// Mapping for the viewParticipationStatus page
	@RequestMapping(value = "/viewParticipationStatus")
	public String viewParticipationStatus(@ModelAttribute("participation") Participation participation, Model m,
			@RequestParam("cId") int cId) {
		List<Participation> statusList = sportsService.viewParticipationById(cId);
		m.addAttribute("statusList", statusList);
		return "viewParticipationStatus";
	}

	// Mapping for forgotPassword page
	@RequestMapping(value = "/forgotPassword")
	public String forgotPassword() {
		return "forgotPassword";
	}

	// Mapping for contacts page
	@RequestMapping(value = "/contactPage")
	public String contactPage() {
		return "contact";
	}

	// Mapping for about page
	@RequestMapping(value = "/aboutPage")
	public String aboutPage() {
		return "about";
	}

	// Mapping for services page
	@RequestMapping(value = "/servicesPage")
	public String servicesPage() {
		return "services";
	}

}
