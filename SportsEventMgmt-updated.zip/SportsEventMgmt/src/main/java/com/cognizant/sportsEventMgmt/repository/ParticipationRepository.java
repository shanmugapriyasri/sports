package com.cognizant.sportsEventMgmt.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cognizant.sportsEventMgmt.model.Participation;

//Repository for Participations

@Repository
public interface ParticipationRepository extends JpaRepository<Participation, Integer> {

	// Repository method for getting all participations based on status

	List<Participation> getParticipationsByStatus(String status);

	// Repository method for getting all participations based on coach id and status

	@Transactional
	@Query("Select p from Participation p where cId=?1 and status=?2")
	List<Participation> getParticipationsByIdStatus(int cId, String status);

	// Repository method for getting all participations based on coach id

	List<Participation> getParticipationsBycId(int cId);

	// Repository method for updating participation status

	@Transactional
	@Modifying
	@Query("update Participation set status =?1 where partId=?2 and eId=?3 and cId=?4")
	void updateParticipation(String status, int partId, int eId, int cId);

	// Repository method for getting all the participations based on the
	// participation and event id

	@Transactional
	@Query("Select p from Participation p where cId=?1 and eId=?2")
	List<Participation> getExistingParticipation(int cId, int eId);
}
