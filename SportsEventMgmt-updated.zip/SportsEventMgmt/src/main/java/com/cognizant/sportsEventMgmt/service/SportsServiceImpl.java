package com.cognizant.sportsEventMgmt.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.sportsEventMgmt.model.Event;
import com.cognizant.sportsEventMgmt.model.Participation;
import com.cognizant.sportsEventMgmt.model.Player;
import com.cognizant.sportsEventMgmt.model.Sports;
import com.cognizant.sportsEventMgmt.model.User;
import com.cognizant.sportsEventMgmt.repository.EventRepository;
import com.cognizant.sportsEventMgmt.repository.ParticipationRepository;
import com.cognizant.sportsEventMgmt.repository.PlayerRepository;
import com.cognizant.sportsEventMgmt.repository.SportsRepository;
import com.cognizant.sportsEventMgmt.repository.UserRepository;

//This is an implementation of service layer

@Service
public class SportsServiceImpl implements SportsService {
	@Autowired
	private UserRepository userRepository;
	@Autowired
	private SportsRepository sportsRepository;
	@Autowired
	private EventRepository eventRepository;
	@Autowired
	private PlayerRepository playerRepository;
	@Autowired
	private ParticipationRepository participationRepository;

	// Service method for registering new users
	@Override
	public void addUser(User user) {
		userRepository.save(user);
	}

	// Service method for authenticating users
	@Override
	public User authenticateUser(String emailId, String password) {
		return (userRepository.authenticateUser(emailId, password));
	}

	// Service method for adding new sports
	@Override
	public void addSports(Sports sports) {
		sportsRepository.save(sports);
	}

	// Service method for getting a sports by id
	@Override
	public Optional<Sports> findSportsById(int id) {
		return sportsRepository.findById(id);
	}

	// Service method for updating an existing sports
	@Override
	public void updateSports(String noOfPlayers, String timeOfMatch, int sId) {
		sportsRepository.updateSports(noOfPlayers, timeOfMatch, sId);
	}

	// Service method for deleting an existing sports
	@Override
	public void deleteSports(int sId) {
		sportsRepository.deleteById(sId);
	}

	// Service method to view all the existing sports
	@Override
	public List<Sports> viewSports() {
		return sportsRepository.findAll();
	}

	// Service method to auto-generate sports name for adding event
	@Override
	public List<String> getSportsList() {
		return (List<String>) sportsRepository.findName();
	}

	// Service method for adding new event
	@Override
	public void addEvent(Event event) {
		eventRepository.save(event);

	}

	// Service method for getting a event by eId
	@Override
	public Optional<Event> findEventById(int eId) {
		return eventRepository.findById(eId);
	}

	// Service method for updating an existing event
	@Override
	public void updateEvent(String eventDate, String eventTime, String noOfSlots, int eId) {
		eventRepository.updatEvent(eventDate, eventTime, noOfSlots, eId);

	}

	// Service method for deleting an existing event
	@Override
	public void deleteEvent(int eId) {
		eventRepository.deleteById(eId);

	}

	// Service method to view all the existing events
	@Override
	public List<Event> viewEvent() {
		return eventRepository.findAll();
	}

	// Service method to auto-generate event name for adding players
	@Override
	public List<Participation> getEventList(int cId, String status) {
		return participationRepository.getParticipationsByIdStatus(cId, status);
	}

	// Service method for adding new players
	@Override
	public void addPlayer(Player player) {
		playerRepository.save(player);
	}

	// Service method for getting the event by its name
	@Override
	public List<Event> getEventListByEventName(String eventName) {
		return eventRepository.getByEventName(eventName);
	}

	// Service method for updating player's event id
	@Override
	public void updatePlayerId(int eId, int pId) {
		playerRepository.updatePlayerId(eId, pId);

	}

	// Service method for getting a player by pId
	@Override
	public Optional<Player> findPlayerById(int pId) {
		return playerRepository.findById(pId);
	}

	// Service method for updating an existing player
	@Override
	public void updatePlayer(String playerName, String emailId, String contactNumber, String age, String gender,
			int pId) {
		playerRepository.updatePlayer(playerName, emailId, contactNumber, age, gender, pId);
	}

	// Service method for deleting an existing player
	@Override
	public void deletePlayer(int pId) {
		playerRepository.deleteById(pId);
	}

	// Service method to view all the existing players
	@Override
	public List<Player> viewPlayerById(int cId) {
		return playerRepository.getPlayerBycId(cId);
	}

	// Service method to add new participations for the events
	@Override
	public void addParticipation(Participation participation) {
		participationRepository.save(participation);
	}

	// Service method to view existing participations based on participation and
	// event id
	@Override
	public List<Participation> viewExistingParticipation(int cId, int eId) {
		return participationRepository.getExistingParticipation(cId, eId);
	}

	// Service method to view all the participations request
	@Override
	public List<Participation> viewParticipation(String status) {
		return participationRepository.getParticipationsByStatus(status);
	}

	// Service method to update an existing participation request
	@Override
	public void updateParticipation(String status, int partId, int eId, int cId) {
		participationRepository.updateParticipation(status, partId, eId, cId);
	}

	// Service method to view participations based on coach id
	@Override
	public List<Participation> viewParticipationById(int cId) {
		return participationRepository.getParticipationsBycId(cId);
	}

}
