package com.cognizant.sportsEventMgmt.repository;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.transaction.annotation.Transactional;

import com.cognizant.sportsEventMgmt.model.Event;

@ExtendWith(SpringExtension.class)
@SpringBootTest
@Transactional
public class EventRepositoryTest {

	@Autowired
	EventRepository eventRepository;

	@Test
	public void set() {
		assertNotNull(eventRepository);
	}

	@Test
	public void testSaveEvent() {
		Event event = new Event("ludo", "ludo king", "08-11-1998", "08:15", "11");
		
		eventRepository.save(event);
		List<Event> e=eventRepository.findTopByOrderById();
		System.out.println(e);
		Event ee=e.get(0);
		assertTrue(ee.geteId()>0);
	}

	@Test
	public void testFindEventById_postive() {

		Event event = eventRepository.getOne(6);
		assertNotNull(event);
	}

	@Test
	public void testFindEventById_negative() {
		try {
			Event event = eventRepository.getOne(62);
			assertNull(event);
		} catch (Exception e) {
			// assertEquals(expected, actual);
		}
	}

	@Test
	public void testUpdateEvent_positive() {
		try {
			Event event = eventRepository.getOne(6);

			eventRepository.updatEvent("08-11-1998", "08:15", "6", 6);

			assertEquals("6", event.getNoOfSlots());
		} catch (Exception e) {
			// assertEquals(expected, actual);
		}
	}

	@Test
	public void testUpdateEvent_negative() {
		try {
			Event event = eventRepository.getOne(62);

			eventRepository.updatEvent("08-11-1998", "08:15", "6", 6);

			assertNull(event);
		} catch (Exception e) {
			// assertEquals(expected, actual);
		}

	}

	@Test
	public void testDeleteEventById_postive() {

		
		Event event = new Event("ludo", "ludo king", "08-11-1998", "08:15", "11");
		eventRepository.save(event);
		List<Event> e=eventRepository.findTopByOrderById();
		System.out.println(e);
		Event ee=e.get(0);
		//give only available eventid
		eventRepository.deleteById(ee.geteId());
try {
	eventRepository.getOne(ee.geteId());
} catch (Exception ex) {
	assertEquals("org.springframework.orm.jpa.JpaObjectRetrievalFailureException", ex.getClass().getName());
	
}
		System.out.println(event);
	}

	@Test
	public void testDeleteEventById_negative() {
		try {
			
			Event event = eventRepository.getOne(101);
		
			eventRepository.deleteById(121);
		
			assertNotNull(event);
		} catch (Exception e) {
			// assertEquals(expected, actual);
		}
	}

	@Test
	public void testViewEvent_positive() {
		try {
			List<Event> elist = eventRepository.findAll();

			assertTrue(elist.size() > 0);
		} catch (Exception e) {

		}
	}

	@Test
	public void testViewEvent_negative() {
		try {
			List<Event> elist = eventRepository.findAll();

			assertFalse(elist.size() < 0);
		} catch (Exception e) {

		}
	}
}
