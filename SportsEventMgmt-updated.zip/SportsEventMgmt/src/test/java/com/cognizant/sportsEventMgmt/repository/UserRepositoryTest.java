package com.cognizant.sportsEventMgmt.repository;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.transaction.annotation.Transactional;

import com.cognizant.sportsEventMgmt.model.User;

@ExtendWith(SpringExtension.class)
@SpringBootTest
@Transactional
public class UserRepositoryTest {

	@Autowired
	UserRepository userRepository;

	@Test
	public void set() {
		assertNotNull(userRepository);
	}

	@Test
	public void testSaveUserAsOrganizer() {
		User user = new User(3, "ramu", "ramu", "Ramu@gmail.com", "8982123241", "21", "male", "Ramu@123", "organizer");

		userRepository.save(user);
		assertNotNull(user.getId());
	}

	@Test
	public void testSaveUserAsCoach() {
		User user = new User(4, "raj", "raj", "Ramu@gmail.com", "8982123241", "21", "male", "Ramu@123", "coach");

		userRepository.save(user);
		assertNotNull(user.getId());
	}

	@Test
	public void testFindUserAsOrgenizerById_postive() {

		User user = userRepository.authenticateUser("soni@gmail.com", "Shriom@123");
		assertEquals(2, user.getId());
	}

	@Test
	public void testFindUserAsOrgenizerById_negative() {
		try {
			User user = userRepository.authenticateUser("soni123@gmail.com", "Shriom@123");
			assertNull(user);
		} catch (Exception e) {
			// assertEquals(expected, actual);
		}
	}

	@Test
	public void testFindUserAsCoachById_postive() {

		User user = userRepository.authenticateUser("somya@gmail.com", "Somya@123");
		assertEquals(1, user.getId());
	}

	@Test
	public void testFindUserAsCoachById_negative() {
		try {
			User user = userRepository.authenticateUser("soni@gmail.com", "Somya@123");
			assertNull(user);
		} catch (Exception e) {
			// assertEquals(expected, actual);
		}
	}

}
