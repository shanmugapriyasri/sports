package com.cognizant.sportsEventMgmt.repository;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.transaction.annotation.Transactional;

import com.cognizant.sportsEventMgmt.model.Sports;

@ExtendWith(SpringExtension.class)
@SpringBootTest
@Transactional
public class SportsRepositoryTest {

	@Autowired
	SportsRepository sportsRepository;

	@Test
	public void set() {
		assertNotNull(sportsRepository);
	}

	@Test
	public void testSaveSports() {
		Sports sports = new Sports(1, "snack and Ladder", "indoor", "4", "08:15");

		sportsRepository.save(sports);
		assertNotNull(sports.getsId());
	}

	@Test
	public void testFindSportsById_postive() {

		Sports sports = sportsRepository.getOne(4);
		assertNotNull(sports);
	}

	@Test
	public void testFindSportsById_negative() {
		try {
			Sports sports = sportsRepository.getOne(62);
			assertNull(sports);
		} catch (Exception e) {
			// assertEquals(expected, actual);
		}
	}

	@Test
	public void testUpdateSports_positive() {
		try {
			Sports sports = sportsRepository.getOne(4);

			sportsRepository.updateSports("10", "12:15", 4);

			assertEquals("10", sports.getNoOfPlayers());
		} catch (Exception e) {
			// assertEquals(expected, actual);
		}
	}

	@Test
	public void testUpdateSports_negative() {
		try {
			Sports sports = sportsRepository.getOne(62);

			sportsRepository.updateSports("10", "12:15", 4);

			assertNull(sports);
		} catch (Exception e) {
			// assertEquals(expected, actual);
		}

	}

	@Test
	public void testDeleteSportsById_postive() {

		Sports sports = new Sports(1, "snack and Ladder", "indoor", "4", "08:15");
		sportsRepository.save(sports);

		System.out.println(sports);
		sportsRepository.deleteById(4);

		System.out.println(sports);
	}

	@Test
	public void testDeleteSportsById_negative() {
		try {
			Sports sports = sportsRepository.getOne(62);
			sportsRepository.deleteById(4);
			assertNotNull(sports);
		} catch (Exception e) {
			// assertEquals(expected, actual);
		}
	}

	@Test
	public void testViewSports_positive() {
		try {
			List<Sports> slist = sportsRepository.findAll();

			assertTrue(slist.size() > 0);
		} catch (Exception e) {

		}
	}

	@Test
	public void testViewSports_negative() {
		try {
			List<Sports> slist = sportsRepository.findAll();

			assertFalse(slist.size() < 0);
		} catch (Exception e) {

		}
	}
}
