package com.cognizant.sportsEventMgmt.controller;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.fail;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

import java.util.ArrayList;
import java.util.HashMap;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

import com.cognizant.sportsEventMgmt.StandaloneMvcTestViewResolver;
import com.cognizant.sportsEventMgmt.controller.SportsController;
import com.cognizant.sportsEventMgmt.model.Event;
import com.cognizant.sportsEventMgmt.model.Player;
import com.cognizant.sportsEventMgmt.model.Sports;
import com.cognizant.sportsEventMgmt.model.User;
import com.cognizant.sportsEventMgmt.service.SportsService;
import com.cognizant.sportsEventMgmt.service.SportsServiceImpl;

@ExtendWith(SpringExtension.class)
@SpringBootTest
@AutoConfigureMockMvc
public class SportsEventMgmtControllerTest {

	@InjectMocks
	SportsController sportsController;

	@Autowired
	MockHttpSession session;

	@Autowired
	private MockMvc mvc;

	//@Autowired
	@MockBean
	SportsServiceImpl sportsService;

	@BeforeEach
	public void setup() {
		// this.controller=new ProductController(productService);
		MockitoAnnotations.initMocks(this);

		this.mvc = MockMvcBuilders.standaloneSetup(this.sportsController).build();
		 this.mvc =
		            MockMvcBuilders.standaloneSetup(sportsController)
		                    .setViewResolvers(new StandaloneMvcTestViewResolver())
		                    .build();
	}

	@Test
	public void beforeAll() {
		assertNotNull(mvc);
		assertNotNull(sportsService);
	}

	@AfterEach
	public void tearDown() throws Exception {

	}

	// @Test
	public void testIndexPage_Positive() {
		User user = null;
		try {
			user = new User();
			RequestBuilder request = MockMvcRequestBuilders.get("/indexPage").flashAttr("user", user);
			mvc.perform(request).andExpect(status().isOk()).andExpect(view().name("index"));

		} catch (Exception exception) {
			fail("Exception");
		}

	}

	@Test
	public void testIndexPage_WrongUrl() {

		try {
			mvc.perform(get("/IndexPagewrong")).andExpect(status().is(404));

		} catch (Exception exception) {
			fail("Exception");
		}

	}

	@Test
	public void testOrganizerHome_Positive() {
		User user = null;
		try {
			user = new User();
			RequestBuilder request = MockMvcRequestBuilders.get("/organizerPage").flashAttr("user", user);
			mvc.perform(request).andExpect(status().isOk()).andExpect(view().name("organizer"));

		} catch (Exception exception) {
			System.out.println("WWWWWW"+exception);
			fail("Exception");
		}

	}

	@Test
	public void testOrganizerHome_WrongUrl() {

		try {
			mvc.perform(get("/organizerPagewrong")).andExpect(status().is(404));

		} catch (Exception exception) {
			fail("Exception");
		}

	}

	@Test
	public void testCoachHome_Positive() {
		User user = null;
		try {
			user = new User();
			RequestBuilder request = MockMvcRequestBuilders.get("/coachPage").flashAttr("user", user);
			mvc.perform(request).andExpect(status().isOk()).andExpect(view().name("coach"));

		} catch (Exception exception) {
			fail("Exception");
		}

	}

	@Test
	public void testCoachHome_WrongUrl() {

		try {
			mvc.perform(get("/CoachHomeewrong")).andExpect(status().is(404));

		} catch (Exception exception) {
			fail("Exception");
		}

	}

	@Test
	public void testaddSportsHome_Positive() {
		Sports sports = null;
		try {
			sports = new Sports();
			RequestBuilder request = MockMvcRequestBuilders.get("/addSports").flashAttr("sports", sports);
			mvc.perform(request).andExpect(status().isOk()).andExpect(view().name("addSports"));

		} catch (Exception exception) {
			fail("Exception");
		}

	}

	@Test
	public void testaddSportsHome_WrongUrl() {

		try {
			mvc.perform(get("/addSportsHomeewrong")).andExpect(status().is(404));

		} catch (Exception exception) {
			fail("Exception");
		}

	}

	@Test
	void testdeleteSportsByIdWithValidId() throws Exception {
		HashMap<String, Object> sessionattr = new HashMap<String, Object>();
		sessionattr.put("slist", new ArrayList<Sports>());

		// HttpSession ses=mock(HttpSession.class);
		RequestBuilder request = MockMvcRequestBuilders.delete("/deleteSports").param("sId", "3").session(session)
				.sessionAttrs(sessionattr);

		mvc.perform(request).andExpect(view().name("redirect:/viewSports"));
		// .andExpect(model().size(5));

	}

	@Test
	public void testviewAllSports() {
		try {
			RequestBuilder request = MockMvcRequestBuilders.get("/viewSports");
			mvc.perform(request).andExpect(status().isOk()).andExpect(view().name("viewSports"));
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	public void testviewAllSports_wrongurl() {
		try {
			RequestBuilder request = MockMvcRequestBuilders.get("/viewallSports");
			mvc.perform(request).andExpect(status().is(404));
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	public void testaddEventHome_Positive() {
		Event event = null;
		try {
			event = new Event();
			RequestBuilder request = MockMvcRequestBuilders.get("/addEvent").flashAttr("event", event);
			mvc.perform(request).andExpect(status().isOk()).andExpect(view().name("addEvent"));

		} catch (Exception exception) {
			fail("Exception");
		}

	}

	@Test
	public void testaddEventHome_WrongUrl() {

		try {
			mvc.perform(get("/addEventHomeewrong")).andExpect(status().is(404));

		} catch (Exception exception) {
			fail("Exception");
		}

	}

	@Test
	void testdeleteEventByIdWithValidId() throws Exception {
		HashMap<String, Object> sessionattr = new HashMap<String, Object>();
		sessionattr.put("eList", new ArrayList<Event>());

		// HttpSession ses=mock(HttpSession.class);
		RequestBuilder request = MockMvcRequestBuilders.delete("/deleteEvent").param("eId", "6").session(session)
				.sessionAttrs(sessionattr);

		mvc.perform(request).andExpect(view().name("redirect:/viewEvent"));
		// .andExpect(model().size(5));

	}

	@Test
	public void testviewAllEvent() {
		try {
			RequestBuilder request = MockMvcRequestBuilders.get("/viewEvent");
			mvc.perform(request).andExpect(status().isOk()).andExpect(view().name("viewEvent"));
		} catch (Exception e) {
			e.printStackTrace();
			fail(e);
		}
	}

	@Test
	public void testviewAllEvent_wrongurl() {
		try {
			RequestBuilder request = MockMvcRequestBuilders.get("/viewallEvent");
			mvc.perform(request).andExpect(status().is(404));
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	public void testaddPlayerHome_Positive() {
		Player player = null;
		try {
			player = new Player(333,101,"dhoni","cricket","dhoni@gmai.com","9879879879","36","male");
			RequestBuilder request = MockMvcRequestBuilders.get("/addPlayer").flashAttr("player", player);
			mvc.perform(request).andExpect(status().isOk()).andExpect(view().name("addPlayer"));

		} catch (Exception exception) {
			System.out.println(exception);
			fail("Exception");
		}

	}

	@Test
	public void testaddPlayerHome_WrongUrl() {

		try {
			mvc.perform(get("/addPlayerHomeewrong")).andExpect(status().is(404));

		} catch (Exception exception) {
			fail("Exception");
		}

	}

	@Test
	void testdeletePlayerByIdWithValidId() throws Exception {
		HashMap<String, Object> sessionattr = new HashMap<String, Object>();
		sessionattr.put("pList", new ArrayList<Player>());

		// HttpSession ses=mock(HttpSession.class);
		RequestBuilder request = MockMvcRequestBuilders.delete("/deletePlayer").param("pId", "9").session(session)
				.sessionAttrs(sessionattr);

		mvc.perform(request).andExpect(view().name("redirect:/viewPlayer"));
		// .andExpect(model().size(5));

	}

	@Test
	public void testviewAllPlayer() {
		try {
			RequestBuilder request = MockMvcRequestBuilders.get("/viewPlayer");
			mvc.perform(request).andExpect(status().isOk()).andExpect(view().name("viewPlayer"));
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	public void testviewAllPlayer_wrongurl() {
		try {
			RequestBuilder request = MockMvcRequestBuilders.get("/viewallPlayer");
			mvc.perform(request).andExpect(status().is(404));
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	public void testviewParticipation() {
		try {
			RequestBuilder request = MockMvcRequestBuilders.get("/viewParticipation");
			mvc.perform(request).andExpect(status().isOk()).andExpect(view().name("viewParticipation"));
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	public void testviewParticipation_wrongurl() {
		try {
			RequestBuilder request = MockMvcRequestBuilders.get("/viewallParticipationr");
			mvc.perform(request).andExpect(status().is(404));
		} catch (Exception e) {
			fail(e);
		}
	}

}
