package com.cognizant.sportsEventMgmt.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.transaction.annotation.Transactional;

import com.cognizant.sportsEventMgmt.model.Event;
import com.cognizant.sportsEventMgmt.model.Participation;
import com.cognizant.sportsEventMgmt.model.Player;
import com.cognizant.sportsEventMgmt.model.Sports;
import com.cognizant.sportsEventMgmt.model.User;
import com.cognizant.sportsEventMgmt.repository.EventRepository;
import com.cognizant.sportsEventMgmt.repository.ParticipationRepository;
import com.cognizant.sportsEventMgmt.repository.PlayerRepository;
import com.cognizant.sportsEventMgmt.repository.SportsRepository;
import com.cognizant.sportsEventMgmt.repository.UserRepository;

@ExtendWith(SpringExtension.class)
@SpringBootTest
@Transactional
public class SportsServiceImplTest {
	@Autowired
	EventRepository eventRepository;

	@Autowired
	ParticipationRepository participationRepository;

	@Autowired
	PlayerRepository playerRepository;
	@Autowired
	SportsRepository sportsRepository;

	@Autowired
	UserRepository userRepository;

	@Test
	public void setUserRepository() {
		assertNotNull(userRepository);
	}

	@Test
	public void setSportsRepository() {
		assertNotNull(sportsRepository);
	}

	@Test
	public void setPlayerRepository() {
		assertNotNull(playerRepository);
	}

	@Test
	public void setParticipationRepository() {
		assertNotNull(participationRepository);
	}

	@Test
	public void setEventRepository() {
		assertNotNull(eventRepository);
	}

	@Test
	public void testSaveEvent() {
		Event event = new Event(14, "ludo", "ludo king", "08-11-1998", "08:15", "11");

		eventRepository.save(event);
		assertNotNull(event.geteId());
	}

	@Test
	public void testFindEventById_postive() {

		Event event = eventRepository.getOne(6);
		assertNotNull(event);
	}

	@Test
	public void testFindEventById_negative() {
		try {
			Event event = eventRepository.getOne(62);
			assertNull(event);
		} catch (Exception e) {
			// assertEquals(expected, actual);
		}
	}

	@Test
	public void testUpdateEvent_positive() {
		try {
			Event event = eventRepository.getOne(6);

			eventRepository.updatEvent("08-11-1998", "08:15", "6", 6);

			assertEquals("6", event.getNoOfSlots());
		} catch (Exception e) {
			// assertEquals(expected, actual);
		}
	}

	@Test
	public void testUpdateEvent_negative() {
		try {
			Event event = eventRepository.getOne(62);

			eventRepository.updatEvent("08-11-1998", "08:15", "6", 6);

			assertNull(event);
		} catch (Exception e) {
			// assertEquals(expected, actual);
		}

	}

	@Test
	public void testDeleteEventById_postive() {

		Event event = new Event(14, "ludo", "ludo king", "08-11-1998", "08:15", "11");
		eventRepository.save(event);

		System.out.println(event);
		eventRepository.deleteById(15);

		System.out.println(event);
	}

	@Test
	public void testDeleteEventById_negative() {
		try {
			Event event = eventRepository.getOne(62);
			eventRepository.deleteById(6);
			assertNotNull(event);
		} catch (Exception e) {
			// assertEquals(expected, actual);
		}
	}

	@Test
	public void testViewEvent_positive() {
		try {
			List<Event> elist = eventRepository.findAll();

			assertTrue(elist.size() > 0);
		} catch (Exception e) {

		}
	}

	@Test
	public void testViewEvent_negative() {
		try {
			List<Event> elist = eventRepository.findAll();

			assertFalse(elist.size() < 0);
		} catch (Exception e) {

		}
	}

	@Test
	public void testSaveParticipationAsAccepted() {
		Participation participation = new Participation(1, 1, 2, "accepted", "somya sri", "chess vijay", "chess");

		participationRepository.save(participation);
		assertNotNull(participation.getPartId());
	}

	@Test
	public void testSaveEventParticipationAsDeclined() {
		Participation participation = new Participation(1, 1, 2, "declined", "somya sri", "chess vijay", "chess");

		participationRepository.save(participation);
		assertNotNull(participation.getPartId());
	}

	@Test
	public void testviewExistingParticipationByCidAndEid_positive() {
		try {
			List<Participation> plist = participationRepository.getExistingParticipation(1, 6);

			assertTrue(plist.size() > 0);
		} catch (Exception e) {

		}
	}

	@Test
	public void testviewExistingParticipationByCidAndEid_negative() {
		try {
			List<Participation> plist = participationRepository.getExistingParticipation(1, 6);

			assertFalse(plist.size() < 0);
		} catch (Exception e) {

		}
	}

	@Test
	public void testviewExistingParticipationByStatusAsAccepted_positive() {
		try {
			List<Participation> plist = participationRepository.getParticipationsByStatus("accepted");

			assertTrue(plist.size() > 0);
		} catch (Exception e) {

		}
	}

	@Test
	public void testviewExistingParticipationByStatusAsAccepted_negative() {
		try {
			List<Participation> plist = participationRepository.getParticipationsByStatus("accepted");

			assertFalse(plist.size() < 0);
		} catch (Exception e) {

		}
	}

	@Test
	public void testviewExistingParticipationByStatusAsDeclined_positive() {
		try {
			List<Participation> plist = participationRepository.getParticipationsByStatus("declined");

			assertTrue(plist.size() > 0);
		} catch (Exception e) {

		}
	}

	@Test
	public void testviewExistingParticipationByStatusAsDeclined_negative() {
		try {
			List<Participation> plist = participationRepository.getParticipationsByStatus("declined");

			assertFalse(plist.size() < 0);
		} catch (Exception e) {

		}
	}

	@Test
	public void testviewExistingParticipationByStatusAsRequested_positive() {
		try {
			List<Participation> plist = participationRepository.getParticipationsByStatus("requested");

			assertTrue(plist.size() > 0);
		} catch (Exception e) {

		}
	}

	@Test
	public void testviewExistingParticipationByStatusAsRequested_negative() {
		try {
			List<Participation> plist = participationRepository.getParticipationsByStatus("requested");

			assertFalse(plist.size() < 0);
		} catch (Exception e) {

		}
	}

	@Test
	public void testviewExistingParticipationById_positive() {
		try {
			List<Participation> plist = participationRepository.getParticipationsBycId(1);

			assertTrue(plist.size() > 0);
		} catch (Exception e) {

		}
	}

	@Test
	public void testviewExistingParticipationById_negative() {
		try {
			List<Participation> plist = participationRepository.getParticipationsBycId(1);

			assertFalse(plist.size() < 0);
		} catch (Exception e) {

		}
	}

	@Test
	public void testUpdateParticipationAsAccepted_positive() {
		try {
			Participation participation = participationRepository.getOne(10);

			participationRepository.updateParticipation("accepted", 10, 6, 1);

			assertEquals("accepted", participation.getStatus());
		} catch (Exception e) {
			// assertEquals(expected, actual);
		}
	}

	@Test
	public void testUpdateParticipationAsAccepted_negative() {
		try {
			Participation participation = participationRepository.getOne(62);

			participationRepository.updateParticipation("accepted", 10, 15, 1);

			assertNull(participation);
		} catch (Exception e) {
			// assertEquals(expected, actual);
		}

	}

	@Test
	public void testUpdateParticipationAsDeclined_positive() {
		try {
			Participation participation = participationRepository.getOne(10);

			participationRepository.updateParticipation("declined", 10, 6, 1);

			assertEquals("declined", participation.getStatus());
		} catch (Exception e) {
			// assertEquals(expected, actual);
		}
	}

	@Test
	public void testUpdateParticipationAsDeclined_negative() {
		try {
			Participation participation = participationRepository.getOne(62);

			participationRepository.updateParticipation("declined", 10, 15, 1);

			assertNull(participation);
		} catch (Exception e) {
			// assertEquals(expected, actual);
		}

	}

	@Test
	public void testSavePlayer() {
		Player player = new Player(10, 2, 5, "raj", "pro kabbadi", "raj@gmail.com", "8982123241", "21", "male");

		playerRepository.save(player);
		assertNotNull(player.getpId());
	}

	@Test
	public void testFindPlayerById_postive() {

		Player player = playerRepository.getOne(9);
		assertNotNull(player);
	}

	@Test
	public void testFindPlayerById_negative() {
		try {
			Player player = playerRepository.getOne(62);
			assertNull(player);
		} catch (Exception e) {
			// assertEquals(expected, actual);
		}
	}

	@Test
	public void testUpdatePlayer_positive() {
		try {
			Player player = playerRepository.getOne(9);

			playerRepository.updatePlayer("raj", "raj@gmail.com", "8982123241", "20", "male", 10);

			assertEquals("20", player.getAge());
		} catch (Exception e) {
			// assertEquals(expected, actual);
		}
	}

	@Test
	public void testUpdatePlayer_negative() {
		try {
			Player player = playerRepository.getOne(62);

			playerRepository.updatePlayer("raj", "raj@gmail.com", "8982123241", "20", "male", 10);

			assertNull(player);
		} catch (Exception e) {
			// assertEquals(expected, actual);
		}

	}

	@Test
	public void testDeletePlayerById_postive() {

		Player player = new Player(10, 2, 5, "raj", "pro kabbadi", "raj@gmail.com", "8982123241", "21", "male");
		playerRepository.save(player);

		System.out.println(player);
		playerRepository.deleteById(9);

		System.out.println(player);
	}

	@Test
	public void testDeletePlayerById_negative() {
		try {
			Player player = playerRepository.getOne(62);
			playerRepository.deleteById(6);
			assertNotNull(player);
		} catch (Exception e) {
			// assertEquals(expected, actual);
		}
	}

	@Test
	public void testViewPlayer_positive() {
		try {
			List<Player> plist = playerRepository.findAll();

			assertTrue(plist.size() > 0);
		} catch (Exception e) {

		}
	}

	@Test
	public void testViewPlayer_negative() {
		try {
			List<Player> plist = playerRepository.findAll();

			assertFalse(plist.size() < 0);
		} catch (Exception e) {

		}
	}

	@Test
	public void testSaveSports() {
		Sports sports = new Sports(1, "snack and Ladder", "indoor", "4", "08:15");

		sportsRepository.save(sports);
		assertNotNull(sports.getsId());
	}

	@Test
	public void testFindSportsById_postive() {

		Sports sports = sportsRepository.getOne(4);
		assertNotNull(sports);
	}

	@Test
	public void testFindSportsById_negative() {
		try {
			Sports sports = sportsRepository.getOne(62);
			assertNull(sports);
		} catch (Exception e) {
			// assertEquals(expected, actual);
		}
	}

	@Test
	public void testUpdateSports_positive() {
		try {
			Sports sports = sportsRepository.getOne(4);

			sportsRepository.updateSports("10", "12:15", 4);

			assertEquals("10", sports.getNoOfPlayers());
		} catch (Exception e) {
			// assertEquals(expected, actual);
		}
	}

	@Test
	public void testUpdateSports_negative() {
		try {
			Sports sports = sportsRepository.getOne(62);

			sportsRepository.updateSports("10", "12:15", 4);

			assertNull(sports);
		} catch (Exception e) {
			// assertEquals(expected, actual);
		}

	}

	@Test
	public void testDeleteSportsById_postive() {

		Sports sports = new Sports(1, "snack and Ladder", "indoor", "4", "08:15");
		sportsRepository.save(sports);

		System.out.println(sports);
		sportsRepository.deleteById(4);

		System.out.println(sports);
	}

	@Test
	public void testDeleteSportsById_negative() {
		try {
			Sports sports = sportsRepository.getOne(62);
			sportsRepository.deleteById(4);
			assertNotNull(sports);
		} catch (Exception e) {
			// assertEquals(expected, actual);
		}
	}

	@Test
	public void testViewSports_positive() {
		try {
			List<Sports> slist = sportsRepository.findAll();

			assertTrue(slist.size() > 0);
		} catch (Exception e) {

		}
	}

	@Test
	public void testViewSports_negative() {
		try {
			List<Sports> slist = sportsRepository.findAll();

			assertFalse(slist.size() < 0);
		} catch (Exception e) {

		}
	}

	@Test
	public void testSaveUserAsOrganizer() {
		User user = new User(3, "ramu", "ramu", "Ramu@gmail.com", "8982123241", "21", "male", "Ramu@123", "organizer");

		userRepository.save(user);
		assertNotNull(user.getId());
	}

	@Test
	public void testSaveUserAsCoach() {
		User user = new User(4, "raj", "raj", "Ramu@gmail.com", "8982123241", "21", "male", "Ramu@123", "coach");

		userRepository.save(user);
		assertNotNull(user.getId());
	}

	@Test
	public void testFindUserAsOrgenizerById_postive() {

		User user = userRepository.authenticateUser("soni@gmail.com", "Shriom@123");
		assertEquals(2, user.getId());
	}

	@Test
	public void testFindUserAsOrgenizerById_negative() {
		try {
			User user = userRepository.authenticateUser("soni123@gmail.com", "Shriom@123");
			assertNull(user);
		} catch (Exception e) {
			// assertEquals(expected, actual);
		}
	}

	@Test
	public void testFindUserAsCoachById_postive() {

		User user = userRepository.authenticateUser("somya@gmail.com", "Somya@123");
		assertEquals(1, user.getId());
	}

	@Test
	public void testFindUserAsCoachById_negative() {
		try {
			User user = userRepository.authenticateUser("soni@gmail.com", "Somya@123");
			assertNull(user);
		} catch (Exception e) {
			// assertEquals(expected, actual);
		}
	}

}
