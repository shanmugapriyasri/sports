package com.cognizant.sportsEventMgmt.repository;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.transaction.annotation.Transactional;

import com.cognizant.sportsEventMgmt.model.Participation;

@ExtendWith(SpringExtension.class)
@SpringBootTest
@Transactional
public class ParticipationRepositoryTest {

	@Autowired
	ParticipationRepository participationRepository;

	@Test
	public void set() {
		assertNotNull(participationRepository);
	}

	@Test
	public void testSaveParticipationAsAccepted() {
		Participation participation = new Participation(1, 1, 2, "accepted", "somya sri", "chess vijay", "chess");

		participationRepository.save(participation);
		assertNotNull(participation.getPartId());
	}

	@Test
	public void testSaveEventParticipationAsDeclined() {
		Participation participation = new Participation(1, 1, 2, "declined", "somya sri", "chess vijay", "chess");

		participationRepository.save(participation);
		assertNotNull(participation.getPartId());
	}

	@Test
	public void testviewExistingParticipationByCidAndEid_positive() {
		try {
			List<Participation> plist = participationRepository.getExistingParticipation(1, 6);

			assertTrue(plist.size() > 0);
		} catch (Exception e) {

		}
	}

	@Test
	public void testviewExistingParticipationByCidAndEid_negative() {
		try {
			List<Participation> plist = participationRepository.getExistingParticipation(1, 6);

			assertFalse(plist.size() < 0);
		} catch (Exception e) {

		}
	}

	@Test
	public void testviewExistingParticipationByStatusAsAccepted_positive() {
		try {
			List<Participation> plist = participationRepository.getParticipationsByStatus("accepted");

			assertTrue(plist.size() > 0);
		} catch (Exception e) {

		}
	}

	@Test
	public void testviewExistingParticipationByStatusAsAccepted_negative() {
		try {
			List<Participation> plist = participationRepository.getParticipationsByStatus("accepted");

			assertFalse(plist.size() < 0);
		} catch (Exception e) {

		}
	}

	@Test
	public void testviewExistingParticipationByStatusAsDeclined_positive() {
		try {
			List<Participation> plist = participationRepository.getParticipationsByStatus("declined");

			assertTrue(plist.size() > 0);
		} catch (Exception e) {

		}
	}

	@Test
	public void testviewExistingParticipationByStatusAsDeclined_negative() {
		try {
			List<Participation> plist = participationRepository.getParticipationsByStatus("declined");

			assertFalse(plist.size() < 0);
		} catch (Exception e) {

		}
	}

	@Test
	public void testviewExistingParticipationByStatusAsRequested_positive() {
		try {
			List<Participation> plist = participationRepository.getParticipationsByStatus("requested");

			assertTrue(plist.size() > 0);
		} catch (Exception e) {

		}
	}

	@Test
	public void testviewExistingParticipationByStatusAsRequested_negative() {
		try {
			List<Participation> plist = participationRepository.getParticipationsByStatus("requested");

			assertFalse(plist.size() < 0);
		} catch (Exception e) {

		}
	}

	@Test
	public void testviewExistingParticipationById_positive() {
		try {
			List<Participation> plist = participationRepository.getParticipationsBycId(1);

			assertTrue(plist.size() > 0);
		} catch (Exception e) {

		}
	}

	@Test
	public void testviewExistingParticipationById_negative() {
		try {
			List<Participation> plist = participationRepository.getParticipationsBycId(1);

			assertFalse(plist.size() < 0);
		} catch (Exception e) {

		}
	}

	@Test
	public void testUpdateParticipationAsAccepted_positive() {
		try {
			Participation participation = participationRepository.getOne(10);

			participationRepository.updateParticipation("accepted", 10, 6, 1);

			assertEquals("accepted", participation.getStatus());
		} catch (Exception e) {
			// assertEquals(expected, actual);
		}
	}

	@Test
	public void testUpdateParticipationAsAccepted_negative() {
		try {
			Participation participation = participationRepository.getOne(62);

			participationRepository.updateParticipation("accepted", 10, 15, 1);

			assertNull(participation);
		} catch (Exception e) {
			// assertEquals(expected, actual);
		}

	}

	@Test
	public void testUpdateParticipationAsDeclined_positive() {
		try {
			Participation participation = participationRepository.getOne(10);

			participationRepository.updateParticipation("declined", 10, 6, 1);

			assertEquals("declined", participation.getStatus());
		} catch (Exception e) {
			// assertEquals(expected, actual);
		}
	}

	@Test
	public void testUpdateParticipationAsDeclined_negative() {
		try {
			Participation participation = participationRepository.getOne(62);

			participationRepository.updateParticipation("declined", 10, 15, 1);

			assertNull(participation);
		} catch (Exception e) {
			// assertEquals(expected, actual);
		}

	}

}
