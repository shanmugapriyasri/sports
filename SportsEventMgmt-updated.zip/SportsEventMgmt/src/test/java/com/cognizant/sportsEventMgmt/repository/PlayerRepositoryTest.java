package com.cognizant.sportsEventMgmt.repository;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.transaction.annotation.Transactional;

import com.cognizant.sportsEventMgmt.model.Player;

@ExtendWith(SpringExtension.class)
@SpringBootTest
@Transactional
public class PlayerRepositoryTest {

	@Autowired
	PlayerRepository playerRepository;

	@Test
	public void set() {
		assertNotNull(playerRepository);
	}

	@Test
	public void testSavePlayer() {
		Player player = new Player(10, 2, 5, "raj", "pro kabbadi", "raj@gmail.com", "8982123241", "21", "male");

		playerRepository.save(player);
		assertNotNull(player.getpId());
	}

	@Test
	public void testFindPlayerById_postive() {

		Player player = playerRepository.getOne(9);
		assertNotNull(player);
	}

	@Test
	public void testFindPlayerById_negative() {
		try {
			Player player = playerRepository.getOne(62);
			assertNull(player);
		} catch (Exception e) {
			// assertEquals(expected, actual);
		}
	}

	@Test
	public void testUpdatePlayer_positive() {
		try {
			Player player = playerRepository.getOne(9);

			playerRepository.updatePlayer("raj", "raj@gmail.com", "8982123241", "20", "male", 10);

			assertEquals("20", player.getAge());
		} catch (Exception e) {
			// assertEquals(expected, actual);
		}
	}

	@Test
	public void testUpdatePlayer_negative() {
		try {
			Player player = playerRepository.getOne(62);

			playerRepository.updatePlayer("raj", "raj@gmail.com", "8982123241", "20", "male", 10);

			assertNull(player);
		} catch (Exception e) {
			// assertEquals(expected, actual);
		}

	}

	@Test
	public void testDeletePlayerById_postive() {

		Player player = new Player(10, 2, 5, "raj", "pro kabbadi", "raj@gmail.com", "8982123241", "21", "male");
		playerRepository.save(player);

		System.out.println(player);
		playerRepository.deleteById(9);

		System.out.println(player);
	}

	@Test
	public void testDeletePlayerById_negative() {
		try {
			Player player = playerRepository.getOne(62);
			playerRepository.deleteById(6);
			assertNotNull(player);
		} catch (Exception e) {
			// assertEquals(expected, actual);
		}
	}

	@Test
	public void testViewPlayer_positive() {
		try {
			List<Player> plist = playerRepository.findAll();

			assertTrue(plist.size() > 0);
		} catch (Exception e) {

		}
	}

	@Test
	public void testViewPlayer_negative() {
		try {
			List<Player> plist = playerRepository.findAll();

			assertFalse(plist.size() < 0);
		} catch (Exception e) {

		}
	}
}
